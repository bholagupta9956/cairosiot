const TEXT_BOX = "text";
const GUAGE = "guage";
const LINE_GRAPH = "line_graph";
const DOUGHNUT_CHART = "doughnut_chart";
const INLINE_DOUGHNUT_CHART = "inline_doughnut_chart";
const TIMESTAMP = "timestamp";

export { TEXT_BOX, GUAGE, LINE_GRAPH, DOUGHNUT_CHART, INLINE_DOUGHNUT_CHART, TIMESTAMP };