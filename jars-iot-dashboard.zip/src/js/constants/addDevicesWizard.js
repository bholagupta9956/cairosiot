const BASIC_DETAILS = "basic_details"
const PARAMETER_DETAILS = "parameter_details"
const CONFIRMATION = "confirmation"

export { BASIC_DETAILS, PARAMETER_DETAILS, CONFIRMATION }
