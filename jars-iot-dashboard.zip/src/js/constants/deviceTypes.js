const POINT_MACHINE = "point_machine";
const DC_TRACK = "dc_track";
const WEATHER_STATION = "weather_station";
const SIGNAL = "signal";

export { POINT_MACHINE, DC_TRACK, WEATHER_STATION, SIGNAL };