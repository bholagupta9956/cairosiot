export const Colors = {
    bgColor : "rgb(232 232 236)",
    boxBorder:"2px solid #1c1cad",
    blue : "#1c1cad"
}