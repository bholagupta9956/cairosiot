We are building a IOT data monitoring dashboard where users can see data getting sent by IOT devices.

### Table of Contents

- [Pages and Routing]

You may also refer to the following artifacts to understand this project:

- [Component Design Concepts](https://docs.google.com/spreadsheets/d/1ztteWTzV5YPhrTXGOc0alNibLcWpNBC_ePU8j5Nvoxo/edit#gid=0)
- [UI design](https://docs.google.com/spreadsheets/d/1ztteWTzV5YPhrTXGOc0alNibLcWpNBC_ePU8j5Nvoxo/edit#gid=1322782838)

## Pages and Routing]
