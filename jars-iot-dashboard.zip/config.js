module.exports = {
  GOOGLE_MAPS_API_KEY: "AIzaSyAQjrv-rX6GqLtWLiLULBDSP4rJRRnrtzU",
  // INVENSE_API_URL: process.env.INVENSE_API_URL || "http://localhost:3000",
  // INVENSE_API_URL_CORS: process.env.INVENSE_API_URL || "http://localhost:3000",
  INVENSE_API_URL:
    process.env.INVENSE_API_URL ||
    "https://mb6c1nzt7b.execute-api.ap-south-1.amazonaws.com/dev",
  INVENSE_API_URL_CORS:
    process.env.INVENSE_API_URL ||
    "https://mb6c1nzt7b.execute-api.ap-south-1.amazonaws.com/dev",
  // INVENSE_API_URL: process.env.INVENSE_API_URL || 'https://vas83xoacg.execute-api.ap-south-1.amazonaws.com/staging' ,
  // INVENSE_API_URL_CORS: process.env.INVENSE_API_URL || "https://vas83xoacg.execute-api.ap-south-1.amazonaws.com/staging",
  WEBSOCKET_ENDPOINT:
    "wss://ibsddv1d12.execute-api.ap-south-1.amazonaws.com/dev",
  AWS_COGNITO_USER_POOL_ID: "ap-south-1_349mzDTwq",
  AWS_COGNITO_CLIENT_ID: "2nneuff2va9hlk9o5934r5gg2u",
  AWS_COGNITO_DOMAIN: "https://jars-dev.auth.ap-south-1.amazoncognito.com",
};
